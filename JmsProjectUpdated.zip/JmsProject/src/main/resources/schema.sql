DROP TABLE IF EXISTS CUSTOMER;
 
CREATE TABLE CUSTOMER (
  customer_id INT AUTO_INCREMENT  PRIMARY KEY,
  customer_name VARCHAR(250) NOT NULL,
  customer_age INT,
  customer_acc_type VARCHAR(250) NOT NULL,
  customer_salary INT
);


DROP TABLE IF EXISTS person;

CREATE TABLE person  (
    person_id INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    email VARCHAR(100),
    age INT
);