INSERT INTO 
	CUSTOMER (customer_id, customer_name, customer_age, customer_acc_type, customer_salary) 
VALUES
  	(1, 'Bansal', 26, 'savings', 1000),
  	(2, 'Ravi', 25, 'current', 2500);