package com.springboot.jmsproject.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.jmsproject.model.Customer;
import com.springboot.jmsproject.repository.CustomerRepository;

@Service
public class CustomerService {
	
	
	  @Autowired CustomerRepository repository;
	  
	  public List<Customer> getAllCustomers() { 
	  List<Customer> result = (List<Customer>) repository.findAll(); 
	  if(result.size() > 0) {
		  System.out.println("result size "+result.size());
		  return result;
	  } else { 
		  return new ArrayList<Customer>(); 
	  	} 
	  }
	 
	
	public void createOrUpdateCustomer(Customer customer) 
		{
			System.out.println(customer.toString());		
	}

}
