package com.springboot.jmsproject.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import com.springboot.jmsproject.model.Customer;

@Component
public class ConsumerComponent {
	
	@Autowired
	JmsTemplate jmsTemplate;
	
	@JmsListener(destination="samplequeue.queue", containerFactory="myFactory")
	public void consumeMessage(Customer customer) {
		System.out.println("Entered in Consumer");
		System.out.println(customer.toString());
	}

}
