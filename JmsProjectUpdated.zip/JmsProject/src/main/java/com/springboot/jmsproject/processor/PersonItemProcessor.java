package com.springboot.jmsproject.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

import com.springboot.jmsproject.model.*;

public class PersonItemProcessor implements ItemProcessor<Person,Person>{
	
	private static Logger log = LoggerFactory.getLogger(PersonItemProcessor.class);

	@Override
	public Person process(Person person) throws Exception {
		// TODO Auto-generated method stub
		
		String firstName = person.getFirstName().toUpperCase();
		String lastName = person.getLastName().toUpperCase();
		
		Person transformedPerson = new Person(firstName, lastName, person.getEmail(), person.getAge());
		log.info("Person-> "+person + " Transformed Person -> "+transformedPerson);
		return transformedPerson;
	}
	
	

}
