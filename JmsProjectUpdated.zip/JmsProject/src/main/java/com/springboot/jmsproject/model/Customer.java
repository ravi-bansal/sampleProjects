package com.springboot.jmsproject.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2805192439130978898L;

	@Id
	@Column(name="customer_id")
	private Integer customerId;
	
	@Column(name="customer_name")
	private String name;
	@Column(name="customer_age")
	private Integer age;
	@Column(name="customer_acc_type")
	private String accountType;
	@Column(name="customer_salary")
	private Integer salary;
	
	
	public Customer() {
		
	}
	
	public Customer(Integer customerId, String name, Integer age, String accountType, Integer salary) {
		this.customerId = customerId;
		this.name = name;
		this.age = age;
		this.accountType = accountType;
		this.salary = salary;
	}
	
	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public Integer getSalary() {
		return salary;
	}
	public void setSalary(Integer salary) {
		this.salary = salary;
	}
	
	

}
