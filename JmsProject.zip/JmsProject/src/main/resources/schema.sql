DROP TABLE IF EXISTS CUSTOMER;
 
CREATE TABLE CUSTOMER (
  customer_id INT AUTO_INCREMENT  PRIMARY KEY,
  customer_name VARCHAR(250) NOT NULL,
  customer_age INT,
  customer_acc_type VARCHAR(250) NOT NULL,
  customer_salary INT
);