package com.springboot.jmsproject.component;

import java.util.List;
import java.util.Optional;

import javax.jms.Queue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.jmsproject.model.Customer;
import com.springboot.jmsproject.service.CustomerService;

@RestController
@RequestMapping("/publish")
public class ProducerComponent {
	
	@Autowired
	public JmsTemplate jmsTemplate;
	@Autowired
	public Queue queue;
	@Autowired
	public CustomerService service;
	
	@RequestMapping("/producer")
	public String publish() {
		
		System.out.println("Entered Here");
		System.out.println("JMS Template" +jmsTemplate.toString());
		
		List<Customer> custList = service.getAllCustomers();
		
		System.out.println("List Size"+custList.size());
		
		Optional<Customer> customer = 
				custList.stream().
				filter(c -> c.getCustomerId().equals(1)).findFirst();
		Customer cust = null;
		if(customer.isPresent()) {
			cust = customer.get();
		}
		jmsTemplate.convertAndSend(queue, cust);
		return "Message Published Successfully";
	}

}
