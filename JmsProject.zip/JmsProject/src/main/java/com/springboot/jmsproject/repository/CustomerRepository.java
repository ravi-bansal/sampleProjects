package com.springboot.jmsproject.repository;

import org.springframework.stereotype.Repository;
import org.springframework.data.repository.CrudRepository;
import com.springboot.jmsproject.model.*;

@Repository
public interface CustomerRepository extends CrudRepository<Customer, Integer>{

}
