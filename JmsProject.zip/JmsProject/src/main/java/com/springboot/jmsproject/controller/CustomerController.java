package com.springboot.jmsproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.jmsproject.model.Customer;
import com.springboot.jmsproject.service.CustomerService;

@RestController
@RequestMapping("/")
public class CustomerController {
	
	@Autowired
	CustomerService service;
	
	@RequestMapping("/hello")
	public String helloWorld() {
		return "list-employees";
	}
	
	
	  @RequestMapping 
	  public String getAllCustomers(Model model) { 
		  List<Customer> list = service.getAllCustomers(); 
		  System.out.println("Controller List Size" +list.size());
		  model.addAttribute("customers", list);
		  return "list-customers"; 
	  }
	 
	 
	
	@RequestMapping(path = "/createCustomer", method = RequestMethod.POST)
	public String createOrUpdateEmployee(Customer customer) 
	{
		service.createOrUpdateCustomer(customer);
		return "redirect:/";
	}

}
